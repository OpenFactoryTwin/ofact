

class StateModelAdaption:

    def __init__(self, state_model):
        self._state_model = state_model

    def add_stationary_resource(self, name: str):
        resources = self._state_model.get_all_resources()  # Get all resources in the state model
        resource = next((r for r in resources if r.name == name), None)  # Search for the resource by name

        # ToDo: ensure that more than one resource can be added
        #  additional resources have different names

        if resource:
            duplicated_resource = resource.duplicate()  # Duplicate the resource
            self._state_model.add_resource(duplicated_resource)  # Add the resource to the state model
            print(f"Stationary resource {name} added successfully.")

            return duplicated_resource
        else:
            print(f"Resource {name} not found in the model.")

    def add_non_stationary_resource(self, name: str):
        resources = self._state_model.get_all_resources()  # Get all resources in the state model
        resource = next((r for r in resources if r.name == name), None)  # Search for the resource by name

        if resource:
            duplicated_resource = resource.duplicate()  # Duplicate the resource
            self._state_model.add_resource(duplicated_resource)  # Add the resource to the state model
            print(f"Non-stationary resource {name} added successfully.")  # Confirm resource was added

            return duplicated_resource
        else:
            print(f"Resource {name} not found in the model.")  # If resource is not found

    def remove_stationary_resource(self, name: str):
        resources = self._state_model.get_all_resources()  # Get all resources in the state model
        resource = next((r for r in resources if r.name == name), None)  # Search for the resource by name

        if resource:
            self._state_model.delete_stationary_resource(resource)  # Replace with the actual method if necessary
            print(f"Stationary resource {name} removed successfully.")  # Confirm removal
        else:
            print(f"Resource {name} not found in the model.")  # If resource is not found

    def remove_non_stationary_resource(self, name: str):
        resources = self._state_model.get_all_resources()
        resource = next((r for r in resources if r.name == name), None)

        if resource:
            self._state_model.delete_non_stationary_resource(resource)
            print(f"Non-stationary resource {name} removed successfully.")
        else:
            print(f"Resource {name} not found.")


if __name__ == "__main__":
    from pathlib import Path
    import pandas as pd

    from ofact.planning_services.model_generation.persistence import deserialize_state_model
    from ofact.twin.repository_services.deserialization.order_types import OrderType

    from projects.bicycle_world.settings import PROJECT_PATH

    print(PROJECT_PATH)

    # Example usage
    path_to_model = "scenarios/current/models/twin/"
    state_model_file_name = "base_wo_material_supply.pkl"

    state_model_file_path = Path(str(PROJECT_PATH), path_to_model + state_model_file_name)
    state_model_generation_settings = {"order_generation_from_excel": False,
                                       "customer_generation_from_excel": True,
                                       "customer_amount": 5,
                                       "order_amount": 20,
                                       "order_type": OrderType.PRODUCT_CONFIGURATOR}
    state_model = deserialize_state_model(state_model_file_path, persistence_format="pkl",
                                          deserialization_required=False,
                                          state_model_generation_settings=state_model_generation_settings)
    state_model_adaption = StateModelAdaption(state_model)

    state_model_adaption.add_stationary_resource("wheel")  # Replace "painting" with the resource name you want to add
    state_model_adaption.add_non_stationary_resource("Main Part AGV 1")

    state_model_adaption.remove_stationary_resource("wheel")  # Replace "painting" with the resource name you want to add
    state_model_adaption.remove_non_stationary_resource("Main Part AGV 1")


